// numerical data
write x,y to `TriangleNewtonCoordinateSeries (maybe rescale maybe not)
write down the t (s and the t) to Gamma

// making equations
what to do about special point? maybe the same?
how many coefficients does the curve have? (maybe just get this from numerical data)?
how do we detect "2-torsion points"? y=0?
